from importlib.metadata import version
from .main import pull_down_a_shutter

# function call
__all__ = ['pull_down_a_shutter']

# version
__version__ = version(__package__)
